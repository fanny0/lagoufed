//此文件作为generator的核心入口文件
// 需要导出一个继承自yeoman Generator 类型的文件
// yeoman Generator 在项目运行时会自动调用我们在此类型中定义的声明周期函数
// 我们在这些方法中可以调用父类提供的一些工具方法完成一些功能，比如说文件的导入

const Generator = require('yeoman-generator')

module.exports = class extends Generator{
    writing () {
        // yeoman自动调用
        // this.fs.write(
        //     this.destinationPath('temp.txt'),//绝对路径
        //     Math.random().toString()
            
        // )
        //模板文件路径
        const tmpl = this.destinationPath('foo.txt')
        //输出路径
        const 
        //
    }
}